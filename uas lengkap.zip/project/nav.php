
<!DOCTYPE html>
<html lang="en" dir=ltr"">
<head>
	<meta charset="utf-8">
	<!-- berikut adalah pemagilan file .css -->
    <link href="style.css" type="text/css" rel="stylesheet" />
    <title>Tembok Sepi</title>
</head>
	<!-- Ini adalah container -->
	<div id="container">
		<!-- Membuat Header-->
			<header>
				<h1>Administrator</h1>
			</header>	
		<!-- Membuat Navigasi-->
			<nav>
				<ul>
					<li><a href="logout.php" title="Logout">Logout </a></li>
				</ul>
			</nav>
			
