<!-- Membuat sidebar -->
		<div class="sidebar">
			<div class="widget-box">
				<h3 class="title"> Menu</h3>
			<ul>
				<li><a href="form_kategori.php"> Tambah Kategori</a></li>
				<li><a href="form_barang.php"> Tambah Barang</a></li>
				<li><a href="data_barang.php"> Data Barang</a></li>
				<li><a href="kategori.php"> Data Kategori</a></li>
				<li><a href="daftar.php"> Data User</a></li>
			</ul>
		</div>

			</div>